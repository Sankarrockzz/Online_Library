<?php
require 'con.php';

$SIGNUP='SIGNUP';
$LOGIN='LOGIN';

$SUCCESSFUL = "2001";
$FAILED = "2002";


if ($_SERVER["REQUEST_METHOD"] == "POST")
{
    $type = $_POST['resqType'];
    if($type == $SIGNUP)
    {
    	$rollno = $_POST['rollno'];
    	$pswrd = $_POST['password'];

    	if($rollno != null && $pswrd != null)
    	{
        		$sql = "INSERT INTO `student`(`roll_no`, `password`) VALUES ('$rollno', '$pswrd')";
    		if($conn->query($sql) === TRUE)
            {
                echo $SUCCESSFUL;
            }else
            {
                echo $FAILED;
            }

    	}
    	else
    	{
    			echo "INVALID rollno or password";
    	}
    	

    }
    else if($type == $LOGIN)
    {
        $rollno = $_POST['rollno'];
        $pswrd = $_POST['password'];

        if($rollno != null && $pswrd != null)
        {
            $sql = "SELECT `roll_no` FROM `student` WHERE roll_no = '$rollno' AND password='$pswrd'";
            $RESULT=$conn->query($sql);
            if($RESULT->num_rows > 0)
            {
                echo $SUCCESSFUL;
            }else
            {
                
                echo "INVALID rollno or password";
            }

        }
        else
        {
                echo "INVALID rollno or password";
        }
    }
}
?>