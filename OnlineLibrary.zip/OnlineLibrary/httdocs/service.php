<?php
require 'con.php';
$ADD_REQ="ADD";//ADD BOOK
$BOOKS_DETAILS_REQ="BOOKS_DETAILS";//SEARCH BOOK NAME OR AUTHOR NAME
$SEARCH_REQ="SEARCH";//SEARCH BOOK NAME OR AUTHOR NAME
$TOPIC="TOPIC";//SEARCH TOPIC WISE
$CATEGORY="CATEGORY";//SEARCH TOPIC WISE

$SUCCESSFUL="SUCCESSFUL";
$FAILED = "FAILED";
$INVALID = 'INAVALID';
$NORESULT = '2002';

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $type = $_POST['resqType'];
    if($type == $ADD_REQ)
    {
    	$BOOK = $_POST['B_NAME'];
    	$AUTHOR =$_POST['A_NAME'];
    	$CATEGORY=$_POST['CATEGORY'];
        $QUANTITY=$_POST['QUANTITY'];
    	$ISBNLIST=$_POST['ISBN_LIST'];

    	if($BOOK !=null && $AUTHOR != null && $CATEGORY != null && $QUANTITY != null){
    		$sql = "INSERT INTO `books`(`book_name`, `book_author`, `quantity`, `category`) VALUES ('$BOOK','$AUTHOR','$QUANTITY,'$CATEGORY')";	
    		if($conn->query($sql) === TRUE){
                /* TODO: INSERt ISBNLIST in isbn table */
            }else
            {
                echo $FAILED;
            }

    	}
    	else
    	{
    		echo $INVALID;
    	}
    }

    else if($type== $BOOKS_DETAILS_REQ){
    	$SEARCH = $_POST['query'];
    	if($SEARCH !=null){
    		$sql="SELECT * FROM `books` WHERE book_name = '$SEARCH'";
    		$RESULT=$conn->query($sql);
    		if($RESULT->num_rows > 0){
                /* SEARCH = book_name */
                $bookList; $count = 0;
    			while($row = $RESULT->fetch_assoc()){
                    $eachBook = new stdClass();
                    $eachBook->book_name = $row["book_name"];
                    $eachBook->author = $row["book_author"];
                    $eachBook->available = $row["quantity"];
                    $eachBook->book_img = $row["book_img"];
                    $eachBook->description = $row["description"];
                    $eachBook->pages = $row["pages"];

                    $bookList[$count++] = $eachBook;
    			}

                echo json_encode($bookList);
    		}else{
                /* SEARCH = author_name */
                $sql = "SELECT * FROM `books` WHERE book_author = '$SEARCH'";
    		    $RESULT=$conn->query($sql);
        		if($RESULT->num_rows > 0){
                    $bookList; $count = 0;
                    while($row = $RESULT->fetch_assoc()){
                        $eachBook = new stdClass();
                        $eachBook->book_name = $row["book_name"];
                        $eachBook->author = $row["book_author"];
                        $eachBook->available = $row["quantity"];
                        $eachBook->book_img = $row["book_img"];
                        $eachBook->description = $row["description"];
                        $eachBook->pages = $row["pages"];

                        $bookList[$count++] = $eachBook;                        
                    }

                    echo json_encode($bookList);

        		}else{
        			echo $NORESULT;
        		}
    		}
    		
    	}else{
            echo $INVALID;
        }
    }else if($type == $SEARCH_REQ){
        $SEARCH = $_POST['query'];
        if($SEARCH !=null){
            /* SEARCH = book_name */
            $sql="SELECT book_name FROM `books` WHERE book_name LIKE '$SEARCH%'";
            $RESULT=$conn->query($sql);
            if($RESULT->num_rows > 0){
                $res = '';
                while ($row = $RESULT->fetch_assoc()) {
                    $res .= $row['book_name'] . ',';
                }
                echo substr($res, 0, strlen($res) - 1);
            }else{
                /* SEARCH = author_name */
                $sql = "SELECT book_author  FROM `books` WHERE book_author LIKE '$SEARCH%'";
                $RESULT=$conn->query($sql);
                if($RESULT->num_rows > 0){
                    $res = '';
                    while ($row = $RESULT->fetch_assoc()) {
                        $res .= $row['book_author'] . ',';
                    }
                echo substr($res, 0, strlen($res) -1);
                }else{
                    echo $NORESULT;
                }

            }
        }else{
            echo $INVALID;
        }   

    }else{
        echo $INVALID;
    } 

}
?>