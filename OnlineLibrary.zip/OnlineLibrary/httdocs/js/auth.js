	/* Set login status*/
	  $(document).ready(function() {
	  	if(sessionStorage.getItem("stu_rollno") != null){
	  		$("#login_status").empty();
	  		$("#login_buttons").empty();

	  		$("#login_buttons").append('<button class="w3-button" onclick="logout()">Logout</button>')
	  		$("#login_status").append('<img style="width: 56px; height: 56px; margin-left:10px;" src="img/stu_avatar.png"><br><h5>You are logged in</h5>');
	  	}else if(sessionStorage.getItem("staff_email") != null){
	  		$("#login_status").empty();
	  		$("#login_buttons").empty();

	  		$("#login_buttons").append('<button class="w3-button" onclick="logout()">Logout</button>')
	  		$("#login_status").append('<img style="width: 56px; height: 56px; margin-left:10px;" src="img/staff_avatar.png"><br><h5>You are logged in</h5>');	  		
	  	}


	  });


	  $(document).ready(function() {
	  	$("#login_form").submit(function(e){
	  		$.ajax({
	  			type: "POST",
				url: "student_auth.php", // it's the URL of your component B
				data: $("#login_form").serialize(), // serializes the form's elements
				success: function(data)
				{
					if(data === "2001"){
						$("#login_status").empty();
						$("#login_buttons").empty();

						$("#login_buttons").append('<button class="w3-button" onclick="logout()">Logout</button>');
						$("#login_status").append('<img style="width: 56px; height: 56px; margin-left:10px;" src="img/stu_avatar.png"><br><h5>You are logged in</h5>');
						/* Save in seesion*/
						var rollno = (($("#login_form").serialize()).split("&")[0]).split("=")[1];
						sessionStorage.setItem("stu_rollno", rollno);   

						var targeted_popup_class = $('[data-popup-close]').attr('data-popup-close');
						$('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);
					}else{
						alert(data);

					}
				},
				error: function (error){
					alert("Error in Ajax !: " + error);
				}	  			
			}	);

	  		e.preventDefault();
	  	});	

	  });

	  $(document).ready(function() {
	  	$("#signup_form").submit(function(e){
	  		$.ajax({
	  			type: "POST",
				url: "student_auth.php", // it's the URL of your component B
				data: $("#signup_form").serialize(), // serializes the form's elements
				success: function(data)
				{
					if(data === "2001"){
						alert("Your are registed with online library");
						$("#login_status").empty();
						$("#login_buttons").empty();

						$("#login_buttons").append('<button class="w3-button" onclick="logout()">Logout</button>');
						$("#login_status").append('<img style="width: 56px; height: 56px; margin-left:10px;" src="img/stu_avatar.png"><br><h5>You are logged in</h5>');
						/* Save in seesion*/
						var rollno = (($("#signup_form").serialize()).split("&")[0]).split("=")[1];
						sessionStorage.setItem("stu_rollno", rollno);   

						var targeted_popup_class = $('[data-popup-close]').attr('data-popup-close');
						$('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);
					}else{
						alert("User already exist " + data);

					}
				},
				error: function (error){
					alert("Error in Ajax !: " + error);
				}	  			
			});

	  		e.preventDefault();
	  	});	

	  });

	  /* STAFF AUTH */
	  $(document).ready(function() {
	  	$("#staff_login_form").submit(function(e){
	  		$.ajax({
	  			type: "POST",
				url: "staff_auth.php", // it's the URL of your component B
				data: $("#staff_login_form").serialize(), // serializes the form's elements
				success: function(data)
				{	
					if(data === "2001"){
						$("#login_status").empty();
						$("#login_buttons").empty();

						$("#login_buttons").append('<button class="w3-button" onclick="logout()">Logout</button>');
						$("#login_status").append('<img style="width: 56px; height: 56px; margin-left:10px;" src="img/staff_avatar.png"><br><h5>You are logged in</h5>');
						/* Save in seesion*/
						var emailId = (($("#staff_login_form").serialize()).split("&")[0]).split("=")[1];
						sessionStorage.setItem("staff_email", emailId);   

						// var targeted_popup_class = ('').attr('data-popup-close');
						$('[data-popup="staff_login_popup"]').fadeOut(350);
					}else{
						alert(data);

					}
				},
				error: function (error){
					alert("Error in Ajax !: " + error);
				}	  			
			});

	  		e.preventDefault();
	  	});	

	  });

	  $(document).ready(function() {
	  	$("#staff_signup_form").submit(function(e){
	  		$.ajax({
	  			type: "POST",
				url: "staff_auth.php", // it's the URL of your component B
				data: $("#staff_signup_form").serialize(), // serializes the form's elements
				success: function(data)
				{
					if(data === "2001"){
						alert("Your are registed with online library");
						$("#login_status").empty();
						$("#login_buttons").empty();

						$("#login_buttons").append('<button class="w3-button" onclick="logout()">Logout</button>');
						$("#login_status").append('<img style="width: 56px; height: 56px; margin-left:10px;" src="img/staff_avatar.png"><br><h5>You are logged in</h5>');
						/* Save in seesion*/
						var emailId = (($("#staff_signup_form").serialize()).split("&")[0]).split("=")[1];
						sessionStorage.setItem("staff_email", emailId);   

						$('[data-popup="staff_login_popup"]').fadeOut(350);
					}else{
						alert("User already exist " + data);

					}
				},
				error: function (error){
					alert("Error in Ajax !: " + error);
				}	  			
			});

	  		e.preventDefault();
	  	});	

	  });

	  function logout(){
	  	sessionStorage.clear();
	  	window.location.reload();
	  }