   function fetchResult() {
    var quey = $('#main_searchBox').val();
    /* Show autocomplete */
    showSearchResult(quey);
  }

    function showSearchResult(reqs){
      $.ajax({
        type: "POST",
        url: "service.php", // it's the URL of your component B
        data: 'resqType=SEARCH&query=' + reqs, // serializes the form's elements
        success: function(data)
        {
          if(data == "2002"){
          }else{ 
            var availableBooks = [];
            availableBooks = data.split(',');
            /* Set autocomplete */
             $("#main_searchBox").autocomplete({
              source: availableBooks
            });
          }
        },
        error: function (error){
          alert("Error in Ajax !: " + error);
        }         
      });

  }

  $(function(){
    $("#main_searchBox").keyup(function (e) {
      if(e.which == 13) {
        finalQuery =  $('#main_searchBox').val();
        sessionStorage.setItem("search_query", finalQuery);
        getBookDetails(finalQuery);
      }
   });
  });

  /* Get search ed book all details */
    function getBookDetails(finalQuery){
     $.ajax({
       type: "POST",
       url: "service.php", // it's the URL of your component B
       data: 'resqType=BOOKS_DETAILS&query=' + finalQuery, // serializes the form's elements
       success: function(data)
       {
         if(data == "2002"){
         }else{
           if(data != ""){
              var bookListObj = JSON.parse(data);
              if(bookListObj.length > 1){
                /*Multi books found*/
                sessionStorage.setItem("query_res", data);
                window.location = "search_result.html";
              }else if(bookListObj.length == 1){
                /*single book found*/
                sessionStorage.setItem("query_res", JSON.stringify(bookListObj[0]));
                window.location = "viewbook.html";
              }
            }
         }
       },
       error: function (error){
         alert("Error in Ajax !: " + error);
       }         
     });
  }
