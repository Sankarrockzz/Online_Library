<?php
require 'con.php';

$ISSUE_REQUEST='issue_request';
$ISSUED_BOOKS_REQUEST='issued_book_request';
$RETURN_REQUEST='return_request';
$INVALID = "invalid";
$NO_BOOK_ISSUED = "2002";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $type = $_POST['resqType'];
    if($type == $ISSUE_REQUEST){
        $rollNo = $_POST['roll_no'];
    	$listofbooks = $_POST['list_of_books'];
        $list = json_decode($listofbooks);
        $isSuccessful = FALSE;
          
        $sql = "SELECT * FROM `issue_table` WHERE roll_no = '$rollNo'";
        $RESULT = $conn->query($sql);
        $curr_count =$RESULT->num_rows; 
        if($curr_count < 3){
            /* Check future order count by add this order to previous/history one */                       
            if((count($list) + $curr_count) <= 3){
                foreach ($list as $eachbook) {
                    $bookName = $eachbook->book_name;
                    $author = $eachbook->author;
                	if($bookName !=null && $author!= null){
                		$sql="SELECT `quantity` FROM `books` WHERE book_name= '$bookName' AND book_author = '$author'";
                		$RESULT = $conn->query($sql);
                        if($RESULT->num_rows > 0){
                            /* Check if quantiy is 0  or not*/                        
                            $row = $RESULT->fetch_assoc();
                    		if($row['quantity'] > 0){ 
                                /* Get ISBN number for the ordered book and insert it into issue_table*/
                	    		$sql="SELECT `isbn` FROM `isbn` WHERE book_name= '$bookName' AND book_author = '$author'";
                                $RESULT = $conn->query($sql);
                                if($RESULT->num_rows> 0){
                                    $row = $RESULT->fetch_assoc();
                    	    		$isbn = $row['isbn'];
                                    $issue_date = date('Y/m/d');
                    	            $return_date = date('Y/m/d', strtotime(date('Y/m/d'). ' + 15 days'));
                                    $sql = "INSERT INTO `issue_table`(`isbn`, `roll_no`, `date_of_issue`, `date_of_return`, `book_name`, `book_author`) VALUES ('$isbn','$rollNo','$issue_date','$return_date','$bookName','$author')";
                                    if($conn->query($sql) === TRUE){
                                        /*Delete/Remove book with the same ISBN from the stock/isbn table */
                                        $sql = "DELETE FROM `isbn` WHERE isbn = '$isbn'";
                                        $conn->query($sql);
                                        if($conn->query("UPDATE `books` SET `quantity` = `quantity` - 1 WHERE book_name = '$bookName' AND book_author = '$author'") === TRUE){
                                            $isSuccessful = TRUE;
                                        }else{
                                            $isSuccessful = FALSE;
                                        }
                                    }                                    
                                }else{
                                    echo "This book is not available";
                                }

                    		}else {
                                echo "No copies available";
                            }  
                        }else{
                            echo "This book is not available";
                        }

                	}else{
                        echo $INVALID; 
                    }
                }
            }else{
                echo "You can order only" . (3-$curr_count) . " more book.";
            }
        }else{
            echo "You have reached you Max. issuing limit";
        }

        if(!$isSuccessful){
            echo "-2002";
        }else{
            echo "-2001";
        }
            
 
	}elseif($type == $ISSUED_BOOKS_REQUEST){
        $rollNo = $_POST['roll_no'];
        $sql = "SELECT issue_table.isbn, issue_table.date_of_issue, issue_table.date_of_return, issue_table.book_name, issue_table.book_author, books.book_img FROM `issue_table` , `books` WHERE `issue_table`.`roll_no` = '$rollNo' AND `issue_table`.`book_name`= `books`.`book_name` AND `issue_table`.`book_author` = `books`.`book_author`";   
        $RESULT = $conn->query($sql);
        if($RESULT->num_rows > 0){
            $bookList = '';
            while($row = $RESULT->fetch_assoc()){
                $bookList .= '{"isbn":"' . $row['isbn'] . '", "doi":"' . $row['date_of_issue'] . '", "dor":"' . $row['date_of_return']. '", "book_name":"' . $row['book_name'] . '", "book_author":"' . $row['book_author'] . '", "book_img":"' . $row['book_img'] . '"},';
            }
            echo '[' . substr($bookList, 0, strlen($bookList) - 1) . ']';
        }else{
            echo $NO_BOOK_ISSUED;
        }
    }elseif($type == $RETURN_REQUEST){
        $rollNo = $_POST['roll_no'];
        $listofbooks = $_POST['list_of_books'];
        $list = json_decode($listofbooks);
        $isSuccessful = FALSE;
        foreach ($list as $eachbook) {
            $bookName = $eachbook->book_name;
            $author = $eachbook->book_author;
            $isbn = $eachbook->isbn;
            /* Delete retured book for thr issue_table */ 
            $sql = "DELETE FROM `issue_table` WHERE isbn = '$isbn'";
            if($conn->query($sql) == TRUE){
                /* Insert the retured book in the stock table (i.e isbn table) */
                $sql = "INSERT INTO `isbn`(`isbn`, `book_name`, `book_author`) VALUES ('$isbn','$bookName','$author')";
                if($conn->query($sql) === TRUE){
                    /* Update/Increment the quentity of the retured book */
                    $sql = "UPDATE `books` SET `quantity` = `quantity` + 1 WHERE book_name = '$bookName' AND book_author = '$author'";
                    if($conn->query($sql) === TRUE){
                        $isSuccessful = TRUE;
                    }else{
                        $isSuccessful = FALSE;
                    }
                }
            }
        }
        if(!$isSuccessful){
            echo "2002";
        }else{
            echo "2001";
        }    
    }    
}
?>