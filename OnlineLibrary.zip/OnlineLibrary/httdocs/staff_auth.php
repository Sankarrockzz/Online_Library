<?php
require 'con.php';

$LOGIN='1000';
$SIGNUP='1001';

$SUCCESSFUL = "2001";
$FAILED = "2002";


if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $type = $_POST['resqType'];
    if($type == $SIGNUP)
    {
    	
        $email = $_POST['email'];
    	$pswrd = $_POST['password'];

    	if($pswrd != null && $email != null)
    	{
    		$sql = "INSERT INTO `staff`(`email`, `password`) VALUES ('$email','$pswrd')";
    		if($conn->query($sql) === TRUE)
            {
                echo $SUCCESSFUL;
            }else
            {
                echo "Email already exist";

            }

    	}
    	else
    	{
                echo "Email already exist";

    	}
    	

    }
    else if($type == $LOGIN)
    {
        $pswrd = $_POST['password'];
        $email = $_POST['email'];

        if($email != null && $pswrd != null)
        {
            $sql = "SELECT `email` FROM `staff` WHERE email= '$email' AND password='$pswrd'";
            $RESULT=$conn->query($sql);
            if($RESULT->num_rows > 0)
            {
                echo $SUCCESSFUL;
            }else
            {
                
                echo "INVALID email or password";

            }

        }
        else
        {
                echo "INVALID email or password";

        }
    }
}
?>