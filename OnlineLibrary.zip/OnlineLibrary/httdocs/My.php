<?php
	 $list_of_books = $_GET['list_of_books'];
	 $list = json_decode($list_of_books);
	 foreach ($list as $eachBook) {
	 	# code...
	 }
	 echo $eachBook->author;
?>