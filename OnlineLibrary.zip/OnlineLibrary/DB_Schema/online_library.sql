-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 18, 2017 at 08:16 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_library`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_name` varchar(50) NOT NULL,
  `book_author` varchar(50) NOT NULL,
  `book_img` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `pages` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_name`, `book_author`, `book_img`, `quantity`, `category`, `description`, `pages`) VALUES
('Advanced microprocessor and Peripherals', 'K M Buruchandi and A K Roy', 'img/books/mpmc_by_bhurchandi.jpg', 4, 'Microprocessor', ' Advanced Microprocessors And Peripherals contains a detailed analysis of the basic concepts and application of technology on microprocessors. Ajoy Kumar Ray and K. M. Bhurchandi make it easy for students to approach the complexities associated with this topic using this book.', 744),
('An Introduction to Datastructures with Application', 'Jean Paul Trembley and Paul G. Sorensen', 'img/books/Data_Structures_by_J_Tremblay_and_P_G_Sorenson_.jpg', 5, 'Datastructure', '\nThis title covers a broad range of algorithms in depth, yet makes their design and analysis accessible to all levels of readers. Each chapter is relatively self-contained and can be used as a unit of study. The algorithms are described in English and in a pseudocode designed to be readable by anyone who has done a little programming. The explanations have been kept elementary without sacrificing depth of coverage or mathematical rigor. (less)\n', 876),
('C how to Program', 'Dietel', 'img/books/c_by_dietel.jpg', 3, 'Programming', 'Key features of the new C standard covered in easyto-include-or-omit modules and an appendix. New Secure C Programming sections. Code tested on GNU gcc and Visual C. GNU gdb and Visual C debugging. Problem solving, data types, control statements, functions, arrays, pointers, strings, formatted I/O, structures, unions, bit manipulation, enumerations, files, data structures, preprocessor and more. "Making a Difference" exercise sets. New treatment of object-oriented programming in C based on C How to Program, 8/e. Searching and sorting with an introduction to Big O', 255),
('Compilers Principles', 'Jeffrey D. Ullman and Alfred V. Aho', 'img/books/cd_aho_sethi_ulman.jpg', 5, 'Compiler Design', 'Compilers: Principles, Techniques and Tools, known to professors, students and developers worldwide as the "Dragon Book, " has been completely revised to reflect the developments in software engineering, programming languages and computer architecture. The authors, recognizing that few readers will ever go on to construct a compiler, retain their focus on the broader set of problems faced in software design and software development.', 1947),
('Computer Fundamentals and Programming in C', 'Reema Thareja', 'img/books/c_by_r_thereja.jpg', 1, 'Programming', 'The book starts with an introduction to C programming and then delves into an in-depth analysis of various constructs of C. The key topics include iterative and decision-control statements, functions, arrays, strings, pointers, structures and unions, file management, and pre-processor directives. It deals separately with the fundamental concepts of various data structures such as linked lists, stacks, queues, trees, and graphs. The book provides numerous case studies linked to the concepts explained in the text.  With its highly detailed pedagogy entailing examples, figures, algorithms, programming tips, and exercises, the book will serve as an ideal resource for students to master and fine-tune the art of writing efficient C programs.', 801),
('Computer Organization', 'Carl Hamacher', 'img/books/co_carl_hamacher.jpg', 6, 'Computer Organization', '*A comprehensive overview of hardware and software issues make this a "must-have" for electrical and computer engineers*Contains new material on RISC processors, performance analysis, multiprocessors and memory systems*New two-color design and illustrations illuminate the text', 1004),
('Computer Organization and Architecture', 'William Stalling', 'img/books/co_william_stalling.jpg', 2, 'Computer Organization', '*A comprehensive overview of hardware and software issues make this a "must-have" for electrical and computer engineers*Contains new material on RISC processors, performance analysis, multiprocessors and memory systems*New two-color design and illustrations illuminate the text', 768),
('Data Communication and Networking', 'Behrouz A Forouzan', 'img/books/forouzan.jpg', 2, 'Networking', 'The update to "Data Communications And Networking by Behrouz Forouzan provides a thorough introduction to the concepts that underlie networking technology. This update provides two new chapters on topics of growing importance. Chapter 26 covers VLANs and VPNs, and chapter 27 covers the increasingly important topic of network security.Forouzan''s approach is accessible to students without technical backgrounds, and also provides material comprehensive enough to challenge the more experienced student. The seven-layer OSI model is used as a framework to provide the background necessary for explaining networking theory and showing interlying dependencies.The second edition of Forouzan''s "Data Communications and Networking includes new exercises and some more challenging ones. In addition, he has increased coverage of some new topics in networking such as some of the new encoding systems, fast Ethernet, 100VganyLan, ADSL and DSL.', 654),
('Database System Concepts', 'Abraham Silberschatz and Henry F. Koarth', 'img/books/A_Silberschatz_H_F_Korth,_S._Sudarshan-Database_System_Concepts,_5th Edition,_McGraw_H', 2, 'Database', '"Database System Concepts," 5/e, is intended for a first course in databases at the junior or senior undergraduate, or first-year graduate, level. In addition to basic material for a first course, the text contains advanced material that can be used for course supplements, or as introductory material for an advanced course.  The authors assume only a familiarity with basic data structures, computer organization, and a high-level programming language such as Java, C, or Pascal. Concepts are presented as intuitive descriptions, and many are based on the running example of a bank enterprise. Important theoretical results are covered, but formal proofs are omitted. In place of proofs, figures and examples are used to suggest why a result is true.', 786),
('Datastructure and Algorithm Analysis in C', 'Mark Allen Weiss', 'img/books/datastructure_in_c_by_weises.jpg', 5, 'Algorithm', ' This title covers a broad range of algorithms in depth, yet makes their design and analysis accessible to all levels of readers. Each chapter is relatively self-contained and can be used as a unit of study. The algorithms are described in English and in a pseudocode designed to be readable by anyone who has done a little programming. The explanations have been kept elementary without sacrificing depth of coverage or mathematical rigor. (less)', 947),
('Datastructures using C', 'Aaron M. Tanenbaum', 'img/books/datastructure_tanenbaum.jpg', 2, 'Datastructure', ' This title covers a broad range of algorithms in depth, yet makes their design and analysis accessible to all levels of readers. Each chapter is relatively self-contained and can be used as a unit of study. The algorithms are described in English and in a pseudocode designed to be readable by anyone who has done a little programming. The explanations have been kept elementary without sacrificing depth of coverage or mathematical rigor. (less)', 0),
('Design and Analysis of Algorithm', 'Manas Ranjan Kabat', 'img/books/daa_by_kabatsir_.jpg', 2, 'Algorithm', ' This title covers a broad range of algorithms in depth, yet makes their design and analysis accessible to all levels of readers. Each chapter is relatively self-contained and can be used as a unit of study. The algorithms are described in English and in a pseudocode designed to be readable by anyone who has done a little programming. The explanations have been kept elementary without sacrificing depth of coverage or mathematical rigor. (less)', 0),
('Fundamantals of Software  Engineering', 'Rajib Mall', 'img/books/rajib_mall.jpg', 2, 'Software Engineering', 'Advancements and rapid developments have led to many ramifications in the ever-changing world of software engineering. This book, in its Fourth Edition, is restructured and extensively revised to trace the advancements made and landmarks achieved in the field. This book not only incorporates latest and enhanced software engineering techniques and practices but also shows how these techniques are applied into the practical software assignments. The chapters are incorporated with illustrative examples to add an analytical insight on the subject. The book is logically organised to cover expanded and revised treatment of all software process activities. New to This Edition* The contents and presentation of all chapters have been improved thoroughly. * Objective type questions have been included in all the chapters. * More practice questions have been added to help students understanding the concepts readily. * McCall''s quality factors and ISO 9126 have been introduced in the chapter dealing with software quality assurance (Chapter 11). * Primarily intended for the undergraduate students of Computer Science and Engineering, the book is also beneficial for the students opting for a course in MCA, MBA and IT. Key Features* Large number of worked-out examples and practice problems. * Chapter-end exercises and solutions to selected problems to check students'' comprehension on the subject. * Solutions manual available for instructors.', 0),
('Fundamentals of Datastructures in C++', 'Ellis Horowitz and Sartaj Sahni', 'img/books/datastr_by_horowich.jpg', 2, 'Datastructure', ' This title covers a broad range of algorithms in depth, yet makes their design and analysis accessible to all levels of readers. Each chapter is relatively self-contained and can be used as a unit of study. The algorithms are described in English and in a pseudocode designed to be readable by anyone who has done a little programming. The explanations have been kept elementary without sacrificing depth of coverage or mathematical rigor. (less)', 0),
('Introduction to Algorithm', 'Thomas H. Coreman', 'img/books/coreman.jpg', 2, 'Algorithm', ' This title covers a broad range of algorithms in depth, yet makes their design and analysis accessible to all levels of readers. Each chapter is relatively self-contained and can be used as a unit of study. The algorithms are described in English and in a pseudocode designed to be readable by anyone who has done a little programming. The explanations have been kept elementary without sacrificing depth of coverage or mathematical rigor. (less)', 0),
('Introduction to Automata Theory, Languages and Com', 'Jeffrey D. Ullman', 'img/books/toc_ullman.jpg', 2, 'Automata', 'This classic book on formal languages, automata theory and computational complexity has been updated to present theoretical concepts in a concise and straightforward manner with the increase of hands-on, practical applications. This new edition comes with Gradiance, an online assessment tool developed for computer science. Gradiance is the most advanced online assessment tool developed for the computer science discipline. With its innovative underlying technology, Gradiance turns basic homework assignments and programming labs into an interactive learning experience for students. By using a series of "root questions" and hints, it not only tests a student''s capability, but actually simulates a one-on-one teacher-student tutorial that allows for the student to more easily learn the material. Through the programming labs, instructors are capable of testing, tracking and honing their students'' skills, both in terms of syntax and semantics, with an unprecedented level of assessment never before offered.', 0),
('Java The Complete Reference', 'Herbert Schildt', 'img/books/java.jpg', 2, 'Programming', 'Fully updated for Java SE 8, Java: The Complete Reference, Ninth Edition explains how to develop, compile, debug, and run Java programs. Bestselling programming author Herb Schildt covers the entire Javalanguage, including its syntax, keywords, and fundamental programming principles, as well as significant portions of the Java API library. JavaBeans, servlets, applets, and Swing are examined and real-world examples demonstrate Java in action. New Java SE 8 features such as lambda expressions, the stream library, and the default interface method are discussed in detail. This Oracle Press resource also offers a solid introduction to JavaFX.', 0),
('Microprocessor and Microcontroller', 'N. Senthil Kumar', 'img/books/mpmc_by_bhurchandi.jpg', 2, 'Microprocessor', ' Advanced Microprocessors And Peripherals contains a detailed analysis of the basic concepts and application of technology on microprocessors. Ajoy Kumar Ray and K. M. Bhurchandi make it easy for students to approach the complexities associated with this topic using this book.', 0),
('Object Oriented Programming With ANSI and  Turbo C', 'Ashok N.Kamthane', 'img/books/oop_by_kamthane.jpg', 2, 'Programming', 'Fully updated for Java SE 8, Java: The Complete Reference, Ninth Edition explains how to develop, compile, debug, and run Java programs. Bestselling programming author Herb Schildt covers the entire Javalanguage, including its syntax, keywords, and fundamental programming principles, as well as significant portions of the Java API library. JavaBeans, servlets, applets, and Swing are examined and real-world examples demonstrate Java in action. New Java SE 8 features such as lambda expressions, the stream library, and the default interface method are discussed in detail. This Oracle Press resource also offers a solid introduction to JavaFX.', 0),
('Object Oriented Programming with C++', 'E Balagurusamy', 'img/books/c++_by_balagurusamy.jpg', 2, 'Programming', 'Fully updated for Java SE 8, Java: The Complete Reference, Ninth Edition explains how to develop, compile, debug, and run Java programs. Bestselling programming author Herb Schildt covers the entire Javalanguage, including its syntax, keywords, and fundamental programming principles, as well as significant portions of the Java API library. JavaBeans, servlets, applets, and Swing are examined and real-world examples demonstrate Java in action. New Java SE 8 features such as lambda expressions, the stream library, and the default interface method are discussed in detail. This Oracle Press resource also offers a solid introduction to JavaFX.', 0),
('Operating Systems Concepts 8th Edition', 'Silberschaz and Galvin', 'img/books/operating_system_by_galvin.jpg', 2, 'Operating systems', 'contains detailed analysis of operating systems', 786),
('Principle of Compiler Design', 'Jeffrey D. Ullman', 'img/books/cd_aho_ulman.jpg', 2, 'Compiler Design', 'Compilers: Principles, Techniques and Tools, known to professors, students and developers worldwide as the "Dragon Book, " has been completely revised to reflect the developments in software engineering, programming languages and computer architecture. The authors, recognizing that few readers will ever go on to construct a compiler, retain their focus on the broader set of problems faced in software design and software development.', 0),
('The C Programming Language', 'Brian W. Kernighan and Denis M.Ritche', 'img/books/c_by_denis_ritche.jpg', 2, 'Programming', 'Key features of the new C standard covered in easyto-include-or-omit modules and an appendix. New Secure C Programming sections. Code tested on GNU gcc and Visual C ®. GNU gdb and Visual C ® debugging. Problem solving, data types, control statements, functions, arrays, pointers, strings, formatted I/O, structures, unions, bit manipulation, enumerations, files, data structures, preprocessor and more. "Making a Difference" exercise sets. New treatment of object-oriented programming in C based on C How to Program, 8/e. Searching and sorting with an introduction to Big O.', 0),
('The Complete Reference C', 'Herbert Schildt', 'img/books/c_by_herbert.jpg', 5, 'Programming', 'Key features of the new C standard covered in easyto-include-or-omit modules and an appendix. New Secure C Programming sections. Code tested on GNU gcc and Visual C ®. GNU gdb and Visual C ® debugging. Problem solving, data types, control statements, functions, arrays, pointers, strings, formatted I/O, structures, unions, bit manipulation, enumerations, files, data structures, preprocessor and more. "Making a Difference" exercise sets. New treatment of object-oriented programming in C based on C How to Program, 8/e. Searching and sorting with an introduction to Big O.', 0),
('Theory of Computation', 'Peter Linz', 'img/books/toc_by_peter_linz.jpg', 2, 'Automata', 'Formal languages, automata, computability, and related matters form the major part of the theory of computation. This textbook is designed for an introductory course for computer science and computer engineering majors who have knowledge of some higher-level programming language', 432);

-- --------------------------------------------------------

--
-- Table structure for table `isbn`
--

CREATE TABLE `isbn` (
  `isbn` varchar(100) NOT NULL,
  `book_name` varchar(100) NOT NULL,
  `book_author` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `isbn`
--

INSERT INTO `isbn` (`isbn`, `book_name`, `book_author`) VALUES
('ISBN10001', 'Computer Organization', 'Carl Hamacher'),
('ISBN10003', 'Computer Organization', 'Carl Hamacher'),
('ISBN10004', 'Computer Organization', 'Carl Hamacher'),
('ISBN10005', 'Computer Organization', 'Carl Hamacher'),
('ISBN10007', 'Computer Organization', 'Carl Hamacher'),
('ISBN10009', 'Data Communication and Networking', 'Behrouz A Forouzan'),
('ISBN10010', 'Database System Concepts', 'Abraham Silberschatz and Henry F. Koarth'),
('ISBN10011', 'Datastructure and Algorithm Analysis in C', 'Mark Allen Weiss'),
('ISBN10012', 'Datastructures using C', 'Aaron M. Tanenbaum'),
('ISBN10013', 'Design and Analysis of Algorithm', 'Manas Ranjan Kabat'),
('ISBN10014', 'Fundamentals of Datastructures in C++', 'Ellis Horowitz and Sartaj Sahni'),
('ISBN10015', 'Java The Complete Reference', 'Thomas H. Coreman'),
('ISBN10016', 'Introduction to Automata Theory, Languages and Com', 'Jeffrey D. Ullman'),
('ISBN10017', 'Java The Complete Reference', 'Herbert Schildt'),
('ISBN10018', 'Microprocessor and Microcontroller', 'N. Senthil Kumar'),
('ISBN10019', 'Object Oriented Programming With ANSI and  Turbo C', 'Ashok N.Kamthane'),
('ISBN10020', 'Object Oriented Programming with C++', 'E Balagurusamy'),
('ISBN10021', 'Principle of Compiler Design', 'Jeffrey D. Ullman'),
('ISBN10022', 'The C Programming Language', 'Brian W. Kernighan and Denis M.Ritche'),
('ISBN20001', 'Advanced microprocessor and Peripherals', 'Peter Linz'),
('ISBN2011', 'Datastructure and Algorithm Analysis in C', 'Mark Allen Weiss'),
('ISBN2012', 'Datastructure and Algorithm Analysis in C', 'Mark Allen Weiss'),
('ISBN2013', 'Datastructure and Algorithm Analysis in C', 'Mark Allen Weiss'),
('ISBN2014\r\n', 'Datastructures using C', 'Aaron M. Tanenbaum'),
('ISBN2014', 'Datastructure and Algorithm Analysis in C', 'Mark Allen Weiss'),
('ISBN2015', 'Datastructure and Algorithm Analysis in C', 'Mark Allen Weiss'),
('ISBN2016', 'Datastructures using C', 'Aaron M. Tanenbaum'),
('ISBN2017', 'Design and Analysis of Algorithm', 'Manas Ranjan Kabat'),
('ISBN2018', 'Design and Analysis of Algorithm', 'Manas Ranjan Kabat'),
('ISBN2019', 'Fundamantals of Software  Engineering', 'Rajib Mall'),
('ISBN2020', 'Fundamantals of Software  Engineering', 'Rajib Mall'),
('ISBN2021', 'Fundamentals of Datastructures in C++', 'Ellis Horowitz and Sartaj Sahni'),
('ISBN2022', 'Fundamentals of Datastructures in C++', 'Ellis Horowitz and Sartaj Sahni'),
('ISBN2027', 'Introduction to Algorithm', 'Thomas H. Coreman'),
('ISBN2028', 'Introduction to Algorithm', 'Thomas H. Coreman'),
('ISBN2034', 'Introduction to Automata Theory, Languages and Com', 'Jeffrey D. Ullman'),
('ISBN2035', 'Introduction to Automata Theory, Languages and Com', 'Jeffrey D. Ullman'),
('ISBN2047', 'Java The Complete Reference', 'Herbert Schildt'),
('ISBN2048', 'Java The Complete Reference', 'Herbert Schildt'),
('ISBN2078', 'Microprocessor and Microcontroller', 'N. Senthil Kumar'),
('ISBN2079', 'Microprocessor and Microcontroller', 'N. Senthil Kumar'),
('ISBN2098', 'Object Oriented Programming With ANSI and  Turbo C', 'Ashok N.Kamthane'),
('ISBN2099', 'Object Oriented Programming With ANSI and  Turbo C', 'Ashok N.Kamthane'),
('ISBN3004', 'Advanced microprocessor and Peripherals', 'K M Buruchandi and A K Roy'),
('ISBN3005', 'Advanced microprocessor and Peripherals', 'K M Buruchandi and A K Roy'),
('ISBN3007', 'Advanced microprocessor and Peripherals', 'K M Buruchandi and A K Roy'),
('ISBN3008', 'Advanced microprocessor and Peripherals', 'K M Buruchandi and A K Roy'),
('ISBN3076', 'Object Oriented Programming with C++', 'E Balagurusamy'),
('ISBN3078', 'Object Oriented Programming with C++', 'E Balagurusamy'),
('ISBN4001', 'An Introduction to Datastructures with Application', 'Jean Paul Trembley and Paul G. Sorensen'),
('ISBN4002', 'An Introduction to Datastructures with Application', 'Jean Paul Trembley and Paul G. Sorensen'),
('ISBN4003', 'An Introduction to Datastructures with Application', 'Jean Paul Trembley and Paul G. Sorensen'),
('ISBN4004', 'An Introduction to Datastructures with Application', 'Jean Paul Trembley and Paul G. Sorensen'),
('ISBN4005', 'An Introduction to Datastructures with Application', 'Jean Paul Trembley and Paul G. Sorensen'),
('ISBN5678\r\n', 'Principle of Compiler Design', 'Jeffrey D. Ullman'),
('ISBN5679', 'Principle of Compiler Design', 'Jeffrey D. Ullman'),
('ISBN6002', 'C how to Program', 'Dietel'),
('ISBN6003', 'C How to Program', 'Dietel'),
('ISBN6004', 'C How to Program', 'Dietel'),
('ISBN6005', 'C How to Program', 'Dietel'),
('ISBN6006', 'C how to Program', 'Dietel'),
('ISBN7001', 'Compilers Principles, Techniques, Tools', 'Jeffrey D. Ullman and Alfred V. Aho'),
('ISBN7002', 'Compilers Principles, Techniques, Tools', 'Jeffrey D. Ullman and Alfred V. Aho'),
('ISBN7003', 'Compilers Principles, Techniques, Tools', 'Jeffrey D. Ullman and Alfred V. Aho'),
('ISBN7004', 'Compilers Principles, Techniques, Tools', 'Jeffrey D. Ullman and Alfred V. Aho'),
('ISBN7005', 'Compilers Principles, Techniques, Tools', 'Jeffrey D. Ullman and Alfred V. Aho'),
('ISBN7089', 'Operating Systems Concepts 8th Edition', 'Silberschaz and Galvin'),
('ISBN7090', 'Operating Systems Concepts 8th Edition', 'Silberschaz and Galvin'),
('ISBN76432', 'Theory of Computation', 'Peter Linz'),
('ISBN7654', 'The Complete Reference C', 'Herbert Schildt'),
('ISBN7655', 'The Complete Reference C', 'Herbert Schildt'),
('ISBN7656', 'The Complete Reference C', 'Herbert Schildt'),
('ISBN7657', 'The Complete Reference C', 'Herbert Schildt'),
('ISBN7658', 'The Complete Reference C', 'Herbert Schildt'),
('ISBN765987', 'Theory of Computation', 'Peter Linz'),
('ISBN9001', 'Computer Fundamentals and Programming in C', 'Reema Thareja'),
('ISBN90010', 'Data Communication and Networking', 'Behrouz A Forouzan'),
('ISBN90011', 'Data Communication and Networking', 'Behrouz A Forouzan'),
('ISBN90012', 'Database System Concepts', 'Abraham Silberschatz and Henry F. Koarth'),
('ISBN90013', 'Database System Concepts', 'Abraham Silberschatz and Henry F. Koarth'),
('ISBN9002', 'Computer Fundamentals and Programming in C', 'Reema Thareja'),
('ISBN9008', 'Computer Organization and Architecture', 'William Stalling'),
('ISBN9009', 'Computer Organization and Architecture', 'William Stalling'),
('ISBN9801', 'The C Programming Language', 'Brian W. Kernighan and Denis M.Ritche'),
('ISBN9878', 'The C Programming Language', 'Brian W. Kernighan and Denis M.Ritche');

-- --------------------------------------------------------

--
-- Table structure for table `issue_table`
--

CREATE TABLE `issue_table` (
  `isbn` varchar(30) NOT NULL,
  `roll_no` varchar(15) NOT NULL,
  `date_of_issue` date NOT NULL,
  `date_of_return` date NOT NULL,
  `book_name` varchar(50) NOT NULL,
  `book_author` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issue_table`
--

INSERT INTO `issue_table` (`isbn`, `roll_no`, `date_of_issue`, `date_of_return`, `book_name`, `book_author`) VALUES
('ISBN10006', '14010234', '2017-04-18', '2017-05-03', 'Computer Fundamentals and Programming in C', 'Reema Thareja'),
('ISBN3001', '14011246', '2017-04-18', '2017-05-03', 'Advanced microprocessor and Peripherals', 'K M Buruchandi and A K Roy'),
('ISBN6001', '14011246', '2017-04-18', '2017-05-03', 'C how to Program', 'Dietel');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`email`, `password`) VALUES
('developer.snkr66@gmail.com', 'snkr123456');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `roll_no` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`roll_no`, `password`) VALUES
('14011241', '1234QWER'),
('14011242', '1234QWER'),
('14011243', '1234QWER'),
('14011244', '1234QWER'),
('14011245', '1234QWER'),
('14011246', 'snkr123456'),
('14011248', '1234QWER'),
('14011249', '1234QWER'),
('14011250', '1234QWER');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `roll_no` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `branch` varchar(5) NOT NULL,
  `total_issued` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`roll_no`, `name`, `email`, `mobile_no`, `branch`, `total_issued`) VALUES
(14010113, 'Pinaki Das', 'pinaki@gmail.com', '9023987654', 'eee', 0),
(14010243, 'Sarans Goyal', 'sarans@gmail.com', '9090938571', 'ee', 0),
(14011231, 'Prabin Mohanty', 'azad47@gmail.com', '7205960104', 'cse', 0),
(14011232, 'Chetna', 'chetna@gmail.com', '9437336606', 'cse', 0),
(14011233, 'Amit Singh', 'amitsingh@gmail.com', '8875878171', 'cse', 0),
(14011241, 'siddharth', 'azadhcv1947@gmail.com', '7205960104', 'cse', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_name`,`book_author`);

--
-- Indexes for table `isbn`
--
ALTER TABLE `isbn`
  ADD PRIMARY KEY (`isbn`);

--
-- Indexes for table `issue_table`
--
ALTER TABLE `issue_table`
  ADD PRIMARY KEY (`isbn`),
  ADD UNIQUE KEY `isbn` (`isbn`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD UNIQUE KEY `password` (`password`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`roll_no`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`roll_no`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
